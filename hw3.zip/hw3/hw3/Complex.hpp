//
//  Complex.hpp
//  hw3
//
//  Created by Jessie Politron on 2/19/19.
//  Copyright © 2019 Jessie Politron. All rights reserved.
//

#ifndef Complex_hpp
#define Complex_hpp
#include <string>
#include <stdio.h>
using namespace std;

class Complex
{
   
public:
     //constructors
    Complex();
    Complex(double real, double imaginary);
    //getters
    double getReal() const {return real;}
    double getImaginary() const {return imaginary;}
    //setters
    void setReal(double real);
    void setImaginary(double imaginary);
    
    Complex add(Complex number);
    Complex subtract(Complex number);
    string toString();
    
private:
    double real;
    double imaginary;

};
#endif /* Complex_hpp */
