//
//  main.cpp
//  hw3
//
//  Created by Jessie Politron on 2/19/19.
//  Copyright © 2019 Jessie Politron. All rights reserved.
//

#include "Complex.hpp"
#include <iostream>
#include <string>

using namespace std;
int main()
{
    Complex number1, number2(18,33);
    cout << number1.toString() << endl;
    cout << number2.toString() << endl;
    
    Complex addNumber = number2.add(number1);
    cout << addNumber.toString() << endl;
    
    Complex subNumber = number2.subtract(number1);
    cout << subNumber.toString() << endl;
    
    subNumber = number1.subtract(number2);
    cout << subNumber.toString() << endl;
    
    return 0;
}
