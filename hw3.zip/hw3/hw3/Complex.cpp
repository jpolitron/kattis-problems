//
//  Complex.cpp
//  hw3
//
//  Created by Jessie Politron on 2/19/19.
//  Copyright © 2019 Jessie Politron. All rights reserved.
//

#include "Complex.hpp"
#include <iostream>
#include <string>

using namespace std;

Complex::Complex()
{
    real = 1;
    imaginary = 1;
}
Complex::Complex(double real, double imaginary)
{
    setReal(real);
    setImaginary(imaginary);
}
void Complex::setReal(double real)
{
    this-> real = real;
}
void Complex::setImaginary(double imaginary)
{
    this-> imaginary = imaginary;
}
Complex Complex::add(Complex number)
{
    double real = getReal()+ number.getReal();
    double imaginary = getImaginary() + number.getImaginary();
    Complex sum(real, imaginary);
    return sum;
}
Complex Complex::subtract(Complex number)
{
    double real = getReal()- number.getReal();
    double imaginary = getImaginary() - number.getImaginary();
    Complex difference(real, imaginary);
    return difference;
}
string Complex::toString()
{
    string print = "(" + to_string(getReal()) + ", " + to_string(getImaginary()) + "i)";
    return print;
}
